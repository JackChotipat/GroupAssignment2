/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MarketAnalytics;

import TheBusiness.MarketModel.Market;

/**
 *
 * @author kal bugrara
 */
public class MarketSummary {
    Market market;
    int revenue;

    public MarketSummary(Market m){

                
    }
                
    }
    
